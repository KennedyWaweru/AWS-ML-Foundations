from setuptools import setup

setup(name='wawerudist',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['wawerudist'],
      zip_safe=False)
